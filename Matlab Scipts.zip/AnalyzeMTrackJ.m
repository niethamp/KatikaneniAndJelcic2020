function [avPL, avPP, avPD, avV,nT] = AnalyzeMTrackJ(data, dT, minPL, PixelPerMicron,AvType)
% by Philipp Niethammer, 2020
%This function extracts tracking point data from MTrackJ (ImageJ) MDF-files to
%calculate tracking parameters
%Note: this is an experimental, minimally annotated analysis script.
% used for Fig. S4
%
%data, tracking data from MDF file (imported by AnalyzeMDF function)
%dT, time interval
%minPL, minimal path length
%PixelPerMicron, pixel aspect ratio
%AvType average type mean or median



RefInd=find(data.MTrackJ=='Reference'); %find reference point coordinates
Rx=data.VarName2(RefInd)*PixelPerMicron;
Ry=data.Data(RefInd)*PixelPerMicron;


trackStart=find(data.MTrackJ=='Track')+1;% find start-indices of tracks
n_tracks=numel(trackStart); 
trackEnd=[trackStart(2:n_tracks)-2;find(data.MTrackJ=='End')-1];

if n_tracks>0 

for i1=1:n_tracks
    if trackStart(i1)<trackEnd(i1)
        
    ind=trackStart(i1):trackEnd(i1); %indices for points in track
    TD(i1)=(data.VarName6(trackEnd(i1))-data.VarName6(trackStart(i1)))*dT; %Track duration
    Px=data.Data(ind)'*PixelPerMicron;
    Py=data.File(ind)'*PixelPerMicron;

    for i2=2:numel(ind) 
        Lp(i2)=pdist([Px(i2-1),Py(i2-1);Px(i2),Py(i2)],'euclidean'); %pathlength between points
    end
    
    PL(i1)=sum(Lp); %Pathlength
    DOE(i1)=pdist([Px(1),Py(1);Px(i2),Py(i2)],'euclidean'); %Distance between origin and end of track
    DOR(i1)=pdist([Px(1),Py(1);Rx,Ry],'euclidean');
    DER(i1)=pdist([Px(i2),Py(i2);Rx,Ry],'euclidean');
    PP(i1)=DOE(i1)/PL(i1); %Path persistance
    PD(i1)=abs(DOR(i1)-DER(i1))/PL(i1); %Path directionality
    V(i1)=PL(i1)/TD(i1);
    
    nT=numel(PL(find(PL>minPL)));
    
    if AvType==1
    avPL=mean(PL(find(PL>minPL)));
    avPP=mean(PP(find(PL>minPL)));
    avPD=mean(PD(find(PL>minPL)));
    avV=mean(V(find(PL>minPL)));
    else
    avPL=median(PL(find(PL>minPL)));
    avPP=median(PP(find(PL>minPL)));
    avPD=median(PD(find(PL>minPL)));
    avV=median(V(find(PL>minPL))); 
    end
    
    else
         nT=NaN;
    avPL=NaN;
    avPP=NaN;
    avPD=NaN;
    avV=NaN;
    end
        
    
end

else
    nT=NaN;
    avPL=NaN;
    avPP=NaN;
    avPD=NaN;
    avV=NaN;
    
    
end

    
    




end

