function [SUMstack] = ND2SUM(iSeries,iT, iC, reader,omeMeta)
% by Philipp Niethammer, 2019
% performs SUM projection (fstack) on specified zstack from ND2
% multidimensional image file
% Note: this is an experimental, minimally annotated analysis script.
% used for Fig. 2a,b; 3a,b; 4c; S1a,e
%
% iSeries: Series (multiposition stage)
% iT: Timepoint
% iC: Channel
% reader: ND2 reader
% omeMeta: Metadata


stackSizeZ = omeMeta.getPixelsSizeZ(0).getValue();
stackSizeX = omeMeta.getPixelsSizeX(0).getValue();
stackSizeY = omeMeta.getPixelsSizeY(0).getValue();

zstack=zeros(stackSizeY,stackSizeX,stackSizeZ);
Zstack=[];

% Read plane from series iSeries at Z, C, T coordinates (iZ, iC, iT)
% All indices are expected to be 1-based


for iZ=1:stackSizeZ
reader.setSeries(iSeries - 1);
iPlane = reader.getIndex(iZ - 1, iC -1, iT - 1) + 1;
zstack(:,:,iZ)=bfGetPlane(reader, iPlane); 
end


SUMstack=uint16(nansum(zstack,3)); %SUM projection
end