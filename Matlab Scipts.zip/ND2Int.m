% script ND2Int V1.0
% by Philipp Niethammer, 2020
% the script reads and processes Nikon .nd2 files for fluorescent region analysis (used for Fig. S1b)  
% Note: this is an experimental, minimally annotated analysis script.

close all

%pick ND2 file
[file,path]=uigetfile('*.nd2');

%initialize reader
reader=bfGetReader([path,file]);

%get metadata
omeMeta = reader.getMetadataStore();

stackSizeT = omeMeta.getPixelsSizeT(0).getValue();


Nfields=omeMeta.getImageCount();
stackSizeX = omeMeta.getPixelsSizeX(0).getValue();
stackSizeY = omeMeta.getPixelsSizeY(0).getValue();

stack=zeros(stackSizeY,stackSizeX);
Zstack=[];


filename=char(omeMeta.getImageName(0));
idx=strfind(filename,'.nd2');
corename=filename(1:(idx-1));
foldername=corename;

for M=1:Nfields
    M
    for T=1:stackSizeT
        
        if T==1
        TransCH=ND2SUM(M,T,1,reader,omeMeta);
        TransCH=imadjust(TransCH);
        FluorCH=ND2SUM(M,T,2,reader,omeMeta);
        ROIbgr=roipoly(TransCH);
        ROIsig=roipoly(TransCH);
        end
        

        TransCH=ND2SUM(M,T,1,reader,omeMeta);
        TransCH=imadjust(TransCH);
        FluorCH=ND2SUM(M,T,2,reader,omeMeta);
        
        BGR=nanmedian(FluorCH(ROIbgr),'all');
        FluorCH_bgr=FluorCH-BGR;
        SIG(M,T)=nanmedian(FluorCH_bgr(ROIsig),'all');
        
        
        
    end
    
    
end



