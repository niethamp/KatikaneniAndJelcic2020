% script ND2ratio V1.0
% by Philipp Niethammer, 2019
% the script reads and processes Nikon .nd2 files for ratiometric C11B ratio analysis 
% Note: this is an experimental, minimally annotated analysis script. Not all
% options are yet fully developed/tested.
% used for Fig. 2a,b; 3a,b;4c; S1e


clear
se = strel('disk',5);
savefile='analysis.mat';
prompt = {'Background Approximation: (1=MedianROI, 2=Mode, 3=Median) ','Smoothing:','Timelapse: (0=no, 1=yes)','Transmitted Light Channel:','Numerator Channel:','Denominator channel:','Wound measurement=1/ROI measurement=2:', 'Save Folder Extension:','Background Threshold:' };
dlgtitle = 'Image Ratio Calculation';
dims = [1 100];
definput = {'2','1','0','1','2','3','1','rat','100'};
answer = inputdlg(prompt,dlgtitle,dims,definput);

bgrOpt=str2num(answer{1});
smoothing=str2num(answer{2});
tlOpt=str2num(answer{3});
trans=str2num(answer{4});
numerator=str2num(answer{5});
denominator=str2num(answer{6});
measureOpt=str2num(answer{7});
SaveExtension=answer{8};
BgrTh=str2num(answer{9});

%pick ND2 file
[file,path]=uigetfile('*.nd2');

%initialize reader
reader=bfGetReader([path,file]);

%get metadata
omeMeta = reader.getMetadataStore();

if tlOpt==0
    stackSizeT=1;
else
    stackSizeT = omeMeta.getPixelsSizeT(0).getValue();
end

Nfields=omeMeta.getImageCount();
stackSizeX = omeMeta.getPixelsSizeX(0).getValue();
stackSizeY = omeMeta.getPixelsSizeY(0).getValue();

stack=zeros(stackSizeY,stackSizeX);
Zstack=[];


filename=char(omeMeta.getImageName(0));
idx=strfind(filename,'.nd2');
corename=filename(1:(idx-1));
foldername=corename;

%Create new folder for saving data

cd (path);
mkdir ([foldername,SaveExtension]);
path=[path,foldername,SaveExtension];
cd (path);


for iSeries=1:Nfields %loop through imaging fields
    
formatSpec = '-----------------------processing stack%3i of%3i-----------------------\n';
fprintf(formatSpec,iSeries,Nfields);
    

   for t=1:stackSizeT %loop through timepoints
   
   transCH=imadjust(ND2SUM(iSeries,t,trans,reader,omeMeta));   
   numCH=ND2SUM(iSeries,t,numerator,reader,omeMeta);
   denCH=ND2SUM(iSeries,t,denominator,reader,omeMeta);
   
   if smoothing>0 %gaussian smoothing
       numCH=imgaussfilt(numCH,smoothing);
       denCH=imgaussfilt(denCH,smoothing);
   end
   
   if bgrOpt==1 % background from ROI
   
       ROIbgr=roipoly(transCH);

       BGRnum=nanmedian(numCH(ROIbgr),'all');
       BGRden=nanmedian(denCH(ROIbgr),'all');
  
       numCHraw=numCH;
       denCHraw=denCH;
       
       numCH=numCH-BGRnum;
       denCH=denCH-BGRden;
       
       
   elseif bgrOpt==2 % global mode background
       
       BGRnum=mode(numCH(numCH<10000));
       BGRden=mode(denCH(denCH<10000));
       
       
       numCHraw=numCH;
       denCHraw=denCH;
       
   
       numCH=numCH-BGRnum;
       denCH=denCH-BGRden;
       
   elseif bgrOpt==3
   end
   
   %************************Calculate and mask ratio***********************
   
   BWmask=imopen(denCH>BgrTh, se); % background threshold
   rat=double(numCH)./double(denCH);
   unmasked_rat=rat;
   rat(~BWmask)=0;

   %*****************Define wound margin and notochord mask****************
   
   imshow(transCH)
   saveRat=uint16(rat.*1000);
   numCH_unmasked=numCH;
   denCH_unmasked=denCH;
   numCH(~numCH)=0;
   denCH(~denCH)=0;
   
   %***********************Save Channels***********************************
   
   if t==1
   imwrite(saveRat,[path,'\M',num2str(iSeries),'rat.tiff'],'tif','Compression','none')
   imwrite(numCH,[path,'\M',num2str(iSeries),'num.tiff'],'tif','Compression','none')
   imwrite(denCH,[path,'\M',num2str(iSeries),'den.tiff'],'tif','Compression','none')
   elseif t>1
   imwrite(saveRat,[path,'\M',num2str(iSeries),'rat.tiff'],'tif','Compression','none','WriteMode','append')
   imwrite(numCH,[path,'\M',num2str(iSeries),'num.tiff'],'tif','Compression','none','WriteMode','append')
   imwrite(denCH,[path,'\M',num2str(iSeries),'den.tiff'],'tif','Compression','none','WriteMode','append')   
   end
   
   if measureOpt==1

   try  %error prone commands, ask to repeat or skip measurement
   errorOpt='Repeat';
   while strcmp(errorOpt,'Repeat')==1
       
   if t==1 %only measure wound margin and notochord ROI in first frame (sample should not be moving much)
   woundmargin=drawpolyline
   wmpolyline=woundmargin.Position;
   BWnotochord = imcomplement(roipoly(transCH));
   end


   BWmask=BWmask&BWnotochord;
   rat(~BWmask)=0;

   
   [y,x]=find(rat>0); %coordinates of all non-zero pixels
   

   d=p_poly_dist(x,y,wmpolyline(:,1),wmpolyline(:,2)); %distance from wound margin
   
   RGBI=impixel(rat,x,y);
   GrayI=RGBI(:,1);
   IvsD=[d,GrayI];
   IvsD=sortrows(IvsD);
   
  IvsD=IvsD(find(IvsD(:,1)>0),:);
%    
  MaxLength=round(max(IvsD(:,1)));
  [N,edges,bins]=histcounts(IvsD(:,1),MaxLength);
  binmedians{iSeries}=splitapply(@median, IvsD(:,2), bins);
  errorOpt='Skip'
  end
   catch
       errorOpt = questdlg('What now?','Script Error','Skip','Repeat','Skip');
       errorOpt=convertCharsToStrings(errorOpt);
       if strcmp(errorOpt,'Skip')==1
       binmedians{iSeries}=NaN;
       elseif strcmp(errorOpt,'Repeat')==1
           iSeries=iSeries-1;
       end
   end
  
  elseif measureOpt==2
  
  ROI=roipoly(transCH)

  ratROI(iSeries)=nanmean(unmasked_rat(ROI),'all')
 
       
 end
  

    
   end %loop through timepoints

    
end %Fields


    
    
    
    


if measureOpt==1
    save(savefile,'binmedians');
elseif measureOpt==2
    save(savefile,'ratROI');
end

   
      


