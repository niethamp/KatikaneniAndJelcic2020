function [results] = AnalyzeMDF(dT,minPL, PixelPerMicron, AvType)
% by Philipp Niethammer, 2020
% Note: this is an experimental, minimally annotated analysis script.
% used for Fig. S4
%
%dT, time interval
%minPL, minimal path length
%PixelPerMicron, pixel aspect ratio
%AvType average type mean or median



%% Select file to load
[file, path]=uigetfile('.mdf','Select One or More Files','MultiSelect', 'on');
%% Input handling


    dataLines = [1, Inf];


%% Setup the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 21);

% Specify range and delimiter
opts.DataLines = dataLines;
opts.Delimiter = " ";

% Specify column names and types
opts.VariableNames = ["MTrackJ", "VarName2", "Data", "File", "VarName5", "VarName6", "VarName7", "VarName8", "VarName9", "VarName10", "VarName11", "VarName12", "VarName13", "VarName14", "VarName15", "VarName16", "VarName17", "VarName18", "VarName19", "VarName20", "VarName21"];
opts.VariableTypes = ["categorical", "double", "double", "double", "double", "double", "double", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";
opts.ConsecutiveDelimitersRule = "join";
opts.LeadingDelimitersRule = "ignore";

% Specify variable properties
opts = setvaropts(opts, ["VarName8", "VarName9", "VarName10", "VarName11", "VarName12", "VarName13", "VarName14", "VarName15", "VarName16", "VarName17", "VarName18", "VarName19", "VarName20", "VarName21"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["MTrackJ", "VarName8", "VarName9", "VarName10", "VarName11", "VarName12", "VarName13", "VarName14", "VarName15", "VarName16", "VarName17", "VarName18", "VarName19", "VarName20", "VarName21"], "EmptyFieldRule", "auto");

% Import the data
results=[];

for i1=1:numel(file)

    data = readtable([path,file{i1}], opts);
    [avPL, avPP, avPD, avV, nT] = AnalyzeMTrackJ(data, dT, minPL, PixelPerMicron, AvType);
    results=[results;[avPL,avPP,avPD,avV, nT]];
    
    
end

end